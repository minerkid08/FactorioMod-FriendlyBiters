
-- Attack Tools

data:extend({
	{
		name = "biterAttackTool",
		type = "selection-tool",
		stack_size = 1,
		icon = data.raw.blueprint.blueprint.icon,
		icon_size = data.raw.blueprint.blueprint.icon_size,
		selection_color = {0, 128, 0},
		selection_cursor_box_type = "entity",
		selection_mode = {"same-force", "entity-with-health"},
		alt_selection_color = {0, 128, 0},
		alt_selection_cursor_box_type = "entity",
		alt_selection_mode = {"same-force", "entity-with-health"}--,
		--entity_filters = filters,
		--alt_entity_filters = filters
	},
	{
		name = "biterAttackSelectTool",
		type = "selection-tool",
		stack_size = 1,
		icon = data.raw.blueprint.blueprint.icon,
		icon_size = data.raw.blueprint.blueprint.icon_size,
		selection_color = {0, 128, 0},
		selection_cursor_box_type = "entity",
		selection_mode = {"entity-with-health"},
		alt_selection_color = {0, 128, 0},
		alt_selection_cursor_box_type = "entity",
		alt_selection_mode = {"entity-with-health"}--,
	},
	{
		type = "recipe",
		name = "biterAttackToolRecipe",
		ingredients = {
			{type="item", name="iron-plate", amount=5},
			{type="item", name="electronic-circuit", amount=3}
		},
		result = "biterAttackTool",
		result_count = 1,
		enabled = false
	},
	{
		type = "recipe",
		name = "biterAttackSelectToolRecipe",
		ingredients = {
			{type="item", name="iron-plate", amount=5},
			{type="item", name="electronic-circuit", amount=3}
		},
		result = "biterAttackSelectTool",
		result_count = 1,
		enabled = false
	},
});

-- Expand Tools

data:extend({
	{
		name = "biterExpandTool",
		type = "selection-tool",
		stack_size = 1,
		icon = data.raw.blueprint.blueprint.icon,
		icon_size = data.raw.blueprint.blueprint.icon_size,
		selection_color = {0, 128, 0},
		selection_cursor_box_type = "entity",
		selection_mode = {"same-force", "entity-with-health"},
		alt_selection_color = {0, 128, 0},
		alt_selection_cursor_box_type = "entity",
		alt_selection_mode = {"same-force", "entity-with-health"}--,
		--entity_filters = filters,
		--alt_entity_filters = filters
	},
	{
		name = "biterExpandSelectTool",
		type = "selection-tool",
		stack_size = 1,
		icon = data.raw.blueprint.blueprint.icon,
		icon_size = data.raw.blueprint.blueprint.icon_size,
		selection_color = {0, 128, 0},
		selection_cursor_box_type = "entity",
		selection_mode = {"any-tile"},
		alt_selection_color = {0, 128, 0},
		alt_selection_cursor_box_type = "entity",
		alt_selection_mode = {"any-tile"}--,
	},
	{
		type = "recipe",
		name = "biterExpandToolRecipe",
		ingredients = {
			{type="item", name="iron-plate", amount=5},
			{type="item", name="electronic-circuit", amount=3}
		},
		result = "biterExpandTool",
		result_count = 1,
		enabled = false
	},
	{
		type = "recipe",
		name = "biterExpandSelectToolRecipe",
		ingredients = {
			{type="item", name="iron-plate", amount=5},
			{type="item", name="electronic-circuit", amount=3}
		},
		result = "biterExpandSelectTool",
		result_count = 1,
		enabled = false
	}
});

-- Technologys

require("prototypes/technology.lua");

-- biters

local smallBiter = table.deepcopy(data.raw.unit["small-biter"]);
local mediumBiter = table.deepcopy(data.raw.unit["medium-biter"]);
local bigBiter = table.deepcopy(data.raw.unit["big-biter"]);
local behemothBiter = table.deepcopy(data.raw.unit["behemoth-biter"]);

smallBiter.name = "friendlySmallBiter";
mediumBiter.name = "friendlyMediumBiter";
bigBiter.name = "friendlyBigBiter";
behemothBiter.name = "friendlyBehemothBiter";

smallBiter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};
mediumBiter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};
bigBiter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};
behemothBiter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};

data:extend({
	smallBiter,
	mediumBiter,
	bigBiter,
	behemothBiter
});

-- spitters

local smallSpitter = table.deepcopy(data.raw.unit["small-spitter"]);
local mediumSpitter = table.deepcopy(data.raw.unit["medium-spitter"]);
local bigSpitter = table.deepcopy(data.raw.unit["big-spitter"]);
local behemothSpitter = table.deepcopy(data.raw.unit["behemoth-spitter"]);

smallSpitter.name = "friendlySmallSpitter";
mediumSpitter.name = "friendlyMediumSpitter";
bigSpitter.name = "friendlyBigSpitter";
behemothSpitter.name = "friendlyBehemothSpitter";

smallSpitter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};
mediumSpitter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};
bigSpitter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};
behemothSpitter.collision_mask = {"player-layer", "train-layer", "not-colliding-with-itself", "layer-55"};

data:extend({
    smallSpitter,
    mediumSpitter,
    bigSpitter,
    behemothSpitter
});

-- spawners

local biterSpawner = table.deepcopy(data.raw["unit-spawner"]["biter-spawner"]);
local spitterSpawner = table.deepcopy(data.raw["unit-spawner"]["spitter-spawner"]);

biterSpawner.name = "friendlyBiterSpawner";
spitterSpawner.name = "friendlySpitterSpawner";

biterSpawner.autoplace = nil;
spitterSpawner.autoplace = nil;

biterSpawner.order = "b-e-b";
spitterSpawner.order = "b-e-b";

biterSpawner.result_units[1][1] = smallBiter.name;
biterSpawner.result_units[2][1] = mediumBiter.name;
biterSpawner.result_units[3][1] = bigBiter.name;
biterSpawner.result_units[4][1] = behemothBiter.name;

spitterSpawner.result_units[1][1] = smallBiter.name;
spitterSpawner.result_units[2][1] = smallSpitter.name;
spitterSpawner.result_units[3][1] = mediumSpitter.name;
spitterSpawner.result_units[4][1] = bigSpitter.name;
spitterSpawner.result_units[5][1] = behemothSpitter.name;

data:extend({
	biterSpawner,
	spitterSpawner
});

-- Tiles

local tile = table.deepcopy(data.raw.tile.concrete);
local tileItem = table.deepcopy(data.raw.item.concrete);
local tileRecipe = table.deepcopy(data.raw.recipe.concrete);

tile.name = "biterWallTile";
tileItem.name = "biterWallTileItem";
tileRecipe.name = "biterWallTileRecipe";

tile.collision_mask = {"layer-55", "ground-tile"};
tile.check_collision_with_entities = true;
tileItem.place_as_tile.result = tile.name;
tileRecipe.result = tileItem.name;
tileRecipe.enabled = true;
tile.minable.result = tileItem.name;

data:extend({
	tile,
	tileItem,
	tileRecipe
});

-- Temp things to increace the evoultion

local evoThing = table.deepcopy(data.raw.furnace["stone-furnace"]);
local evoThingItem = table.deepcopy(data.raw.item["stone-furnace"]);

evoThing.crafting_categories = {"evo"};
evoThing.name = "evoThing";

evoThingItem.name = "evoThingItem";
evoThingItem.place_result = "evoThing";

data:extend({evoThing, evoThingItem});

data:extend({
	{
		type = "recipe-category",
		name = "evo"
	},
	{
		type = "item",
		name = "greenThing",
		stack_size = "100",
		icon = data.raw.item["electronic-circuit"].icon,
		icon_size = data.raw.item["electronic-circuit"].icon_size,
	},
	{
		type = "item",
		name = "processedGreenThing",
		stack_size = "100",
		icon = data.raw.item["advanced-circuit"].icon,
		icon_size = data.raw.item["advanced-circuit"].icon_size,
	},
	{
		type = "recipe",
		name = "processGreenThing",
		ingredients = {
			{type="item", name="greenThing", amount=5}
		},
		result = "processedGreenThing",
		subgroup = "intermediate-product",
		result_count = 1,
		category = "evo",
		enabled = false
	},
	{
		type = "recipe",
		name = "makeEvoThing",
		subgroup = "production-machine",
		ingredients = {
			{type="item", name="stone", amount=69}
		},
		result = "evoThingItem",
		result_count = 1,
		enabled = false
	},
	{
		type = "recipe",
		name = "makeGreenThing",
		subgroup = "intermediate-product",
		ingredients = {
			{type="item", name="wood", amount=10},
			{type="item", name="coal", amount=10},
		},
		result = "greenThing",
		result_count = 1,
		enabled = false
	}
})