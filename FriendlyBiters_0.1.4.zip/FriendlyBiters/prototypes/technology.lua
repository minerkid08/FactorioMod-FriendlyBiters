function generateUpgradeTech(ingredients, tier, prerequisites, name)
	local tech = {
		type = "technology",
		name = name.."-"..tostring(tier),
		icon = "__FriendlyBiters__/graphics/technology/nest.png",
		icon_size = 512,
		prerequisites = {},
		unit = {
			ingredients = {},
			time = 30,
			count = 100 * tier * tier
		},
		upgrade = true
	};
	for k,v in pairs(ingredients) do
		table.insert(tech.unit.ingredients, {v, 1});
	end
	for k,v in pairs(prerequisites) do
		table.insert(tech.prerequisites, v);
	end
	if(tier > 1) then
		table.insert(tech.prerequisites, name.."-"..tostring(tier - 1));
	end
	return tech;
end

-- Evo upgrade

local ingredients = {
	{
		"automation-science-pack",
		"logistic-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack",
		"production-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack",
		"production-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack",
		"production-science-pack",
		"utility-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack",
		"production-science-pack",
		"utility-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack",
		"production-science-pack",
		"utility-science-pack",
		"space-science-pack"
	},
	{
		"automation-science-pack",
		"logistic-science-pack",
		"chemical-science-pack",
		"production-science-pack",
		"utility-science-pack",
		"space-science-pack"
	},
};

local prerequisites = {
	{
		"logistic-science-pack",
		"evoToolTech"
	},
	{},
	{
		"chemical-science-pack"
	},
	{},
	{
		"production-science-pack"
	},
	{},
	{
		"utility-science-pack"
	},
	{},
	{
		"space-science-pack"
	},
	{}
}

for k,v in pairs(prerequisites) do
	data:extend({generateUpgradeTech(ingredients[k], k, v, "evoultionCapUpgrade")});
end

-- Evo tool tech

data:extend({
	{
		type = "technology",
		name = "evoToolTech",
		icon = "__FriendlyBiters__/graphics/technology/nest.png",
		icon_size = 512,
		prerequisites = {"logistic-science-pack"},
		unit = {
			ingredients = {{"automation-science-pack", 1}, {"logistic-science-pack", 1}},
			time = 30,
			count = 200
		},
		effects = {
			{type = "unlock-recipe", recipe = "makeEvoThing"},
			{type = "unlock-recipe", recipe = "makeGreenThing"},
			{type = "unlock-recipe", recipe = "processGreenThing"}
		}
	}
})

-- Biter tools tech

data:extend({
	 {
		type = "technology",
		name = "biterControl",
		icon = "__FriendlyBiters__/graphics/technology/biter.png",
		icon_size = 512,
		prerequisites = {"logistic-science-pack"},
		unit = {
			ingredients = {
				{"automation-science-pack", 1},
				{"logistic-science-pack", 1}
			},
			time = 30,
			count = 150
		},
		effects = {
			{type = "unlock-recipe", recipe = "biterAttackSelectToolRecipe"},
			{type = "unlock-recipe", recipe = "biterAttackToolRecipe"}
		}
	},
	{
		type = "technology",
		name = "biterExpansion",
		icon = "__FriendlyBiters__/graphics/technology/biter.png",
		icon_size = 512,
		prerequisites = {"logistic-science-pack"},
		unit = {
			ingredients = {
				{"automation-science-pack", 1},
				{"logistic-science-pack", 1}
			},
			time = 30,
			count = 150
		},
		effects = {
			{type = "unlock-recipe", recipe = "biterExpandToolRecipe"},
			{type = "unlock-recipe", recipe = "biterExpandSelectToolRecipe"}
		}
	}
});