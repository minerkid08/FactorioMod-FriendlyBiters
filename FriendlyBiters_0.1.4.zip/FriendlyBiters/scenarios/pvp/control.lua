script.on_init(
	function()
		global.teamIndex = 0;
		local position = game.get_surface(1).find_non_colliding_position("biter-spawner", {0,0}, 5, 0.5);

		remote.call("FriendlyBitersInterface", "addForce", "team1");
        remote.call("FriendlyBitersInterface", "addForce", "team2");
		local position = game.get_surface(1).find_non_colliding_position("biter-spawner", {0,0}, 5, 0.5);
		game.get_surface(1).create_entity({
			name = "friendlyBiterSpawner",
			force = "team1",
			position = position
		});
		local pos = game.get_surface(1).find_non_colliding_position("biter-spawner", {200,0}, 5, 0.5);
		game.get_surface(1).create_entity({
			name = "friendlyBiterSpawner",
			force = "team2",
			position = pos
		});
		local force = game.forces["team2"];
		force.set_spawn_position(game.get_surface(1).find_non_colliding_position("biter-spawner", pos, 5, 0.5), 1);
	end
)
script.on_event(
	defines.events.on_player_joined_game,
	function(event)
		local player = game.players[event.player_index];
		if(player.force == game.forces["player"]) then
			if(global.teamIndex == 0) then
				player.force = game.forces["team1"];
				global.teamIndex = 1;
			else
				player.force = game.forces["team2"];
				global.teamIndex = 0;
				player.teleport(game.surface.find_non_colliding_position("character", player.force.get_spawn_position(game.get_surface(1), 5, 0.5 )));
			end
			player.print("joined team: " .. player.force.name);
		end
	end
);