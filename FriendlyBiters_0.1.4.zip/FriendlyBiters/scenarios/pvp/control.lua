script.on_init(
	function()
		if(remote.interfaces["freeplay"]) then
			remote.call("freeplay", "set_skip_intro", true);
			remote.call("freeplay", "set_disable_crashsite", true);
		end
		local position = game.get_surface(1).find_non_colliding_position("biter-spawner", {0,0}, 5, 0.5);
		game.get_surface(1).create_entity({
			name = "friendlyBiterSpawner",
			force = "player",
			position = position
		});
	end
)