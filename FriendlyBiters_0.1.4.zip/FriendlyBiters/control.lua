global.forces = {};
function configForce(name)
	local force = game.forces[name];
	force.evolution_factor_by_pollution = 0;
	force.evolution_factor_by_time = 0;
	force.evolution_factor_by_killing_spawners  = 0;
	global.forces[name] = {};
	global.forces[name].buildBaseGroups = {};
	global.forces[name].evoThing = {};
	global.forces[name].evoPoints = 0;
	global.forces[name].evoCap = 0;
end
script.on_init(
	function()
		if(remote.interfaces["freeplay"]) then
			remote.call("freeplay", "set_skip_intro", true);
			remote.call("freeplay", "set_disable_crashsite", true);
			local position = game.get_surface(1).find_non_colliding_position("biter-spawner", {0,0}, 5, 0.5);
			game.get_surface(1).create_entity({
				name = "friendlyBiterSpawner",
				force = "player",
				position = position
			});
			configForce("player")
		end
	end
)

remote.add_interface("FriendlyBitersInterface", {
  getGlobal = function(key) return global[key] end,
  setGlobal = function(key, value) global[key] = value end,
  addForce = function(name) 
		game.create_force(name); 
		configForce(name); 
	end
})

script.on_event(
	{
		defines.events.on_built_entity,
		defines.events.on_robot_built_entity,
		defines.events.script_raised_built,
		defines.events.script_raised_revive
	}, 
	function(event)
		local ent = event.entity or event.created_entity;
		if(ent.name == "evoThing") then
			local force = ent.force;
			global.forces[force.name].evoThing[ent.unit_number] = ent;
		end
	end
)

script.on_event(
	{
		defines.events.on_entity_died,
		defines.events.on_player_mined_entity,
		defines.events.on_robot_mined_entity,
		defines.events.script_raised_destroy,
	}, 
	function(event)
		local ent = event.entity or event.created_entity;
		if(ent.name == "evoThing") then
			global.forces[ent.force.name].evoThing[ent.unit_number] = nil;
		end
	end
)

script.on_event(
	defines.events.on_player_selected_area, 
	function(event)
		if(event.item == "biterAttackSelectTool") then
			if(type(event.entities) == "table") then
				if(next(event.entities) == nil) then
					return;
				end
				global.forces[game.players[event.player_index].force.name].target = event.entities[1];
			end
		end
		if(event.item == "biterExpandSelectTool") then
			if(event.tiles ~= nil) then
				global.forces[game.players[event.player_index].force.name].target = event.tiles[1];
			end
		end

		if(event.item == "biterAttackTool") then
			if(global.forces[game.players[event.player_index].force.name].target == nil) then
				return;
			end
			if(event.entities == nil) then 
				return;
			end
			if(next(event.entities) == nil) then
				return;
			end
			local group = event.surface.create_unit_group{position = event.entities[1].position, force = game.players[event.player_index].force.name};
			for k,v in pairs(event.entities) do
				if(v.type == "unit") then
					group.add_member(v);
				end
			end
			group.set_command({
				type = defines.command.attack,
				target = global.forces[game.players[event.player_index].force.name].target,
				distraction = defines.distraction.none
			});
		end

		if(event.item == "biterExpandTool") then
			if(global.forces[game.players[event.player_index].force.name].target == nil) then
				return;
			end
			if(event.entities == nil) then 
				return;
			end
			if(next(event.entities) == nil) then
				return;
			end
			local group = event.surface.create_unit_group{position = event.entities[1].position, force = game.players[event.player_index].force.name};
			local v = event.entities[1];
			if(v.type == "unit") then
				group.add_member(v);
			end
			group.set_command({
				type = defines.command.go_to_location,
				destination = global.forces[game.players[event.player_index].force.name].target.position,
				distraction = defines.distraction.none
			});
			table.insert(global.forces[game.players[event.player_index].force.name].buildBaseGroups, group);
		end
	end
)
script.on_event(
	defines.events.on_tick,
	function()
		for forceName,force in pairs(global.forces) do
			--game.players[1].print(force.buildBaseGroups);
			for k,v in pairs(force.buildBaseGroups) do
				if(v.valid) then
					if(v.state == defines.group_state.finished) then
						local position = game.get_surface(1).find_non_colliding_position("biter-spawner", v.position, 5, 0.5);
						if(position ~= nil) then
							v.destroy();
							local spawn = nil;
							if(math.random(1,2) == 1) then
								spawn = "friendlyBiterSpawner";
							else
								spawn = "friendlySpitterSpawner";
							end
							game.get_surface(1).create_entity({
								name = spawn,
								force = forceName,
								position = position
							});
							force.buildBaseGroups[k] = nil;
						end
					end
				end
			end
			local evoPoints = 0;
			for k,v in pairs(force.evoThing) do
				local inventory = v.get_inventory(defines.inventory.furnace_result);
				if(inventory.is_empty() == false) then
					local count = inventory.get_item_count("processedGreenThing");
					evoPoints = evoPoints + count;
					inventory.clear();
				end
			end
			local evoFactor = force.evoPoints + (evoPoints / 100);
			local factor = -math.pow(1.4,-evoFactor) + 1;
			if(factor <= force.evoCap) then
				force.evoPoints = evoFactor;
				if(evoFactor >= 14) then
					game.forces[forceName].evolution_factor = 1;
				else
					game.forces[forceName].evolution_factor = factor;
				end
			else
				game.forces[forceName].evolution_factor = force.evoCap;
			end
		end
	end
)
script.on_event(
	defines.events.on_research_finished,
	function(event)
		if(string.sub(event.research.name, 1, -3) == "evoultionCapUpgrade") then
			--game.players[1].print(global.forces[event.research.force.name]);
			global.forces[event.research.force.name].evoCap = global.forces[event.research.force.name].evoCap + 0.1;
		end
	end
);