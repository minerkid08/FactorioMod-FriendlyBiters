script.on_init(
	function()
		global.forces = {player = {}};
		global.teamIndex = 0;
		global.spawnPos = game.forces["player"].get_spawn_position(game.get_surface(1));
		global.spawnPos.x = global.spawnPos.x + 300;
		if(remote.interfaces["freeplay"]) then
			remote.call("freeplay", "set_skip_intro", true);
			remote.call("freeplay", "set_disable_crashsite", true);
		end
		game.create_force("team1");
		game.create_force("team2");
		local position = game.get_surface(1).find_non_colliding_position("biter-spawner", {0,0}, 5, 0.5);
		game.get_surface(1).create_entity({
			name = "friendlyBiterSpawner",
			force = "team1",
			position = position
		});
		game.forces["player"].evolution_factor_by_pollution = 0;
		game.forces["player"].evolution_factor_by_time = 0;
		game.forces["player"].evolution_factor_by_killing_spawners  = 0;
		global.forces["player"].buildBaseGroups = {};
		global.forces["player"].evoThing = {};
		global.forces["player"].evoPoints = 0;
		global.forces["player"].evoCap = 0;
	end
)
script.on_event(
	defines.events.on_player_joined_game,
	function(event)
		local player = game.players[event.player_index];
		if(player.force == game.forces["player"]) then
			if(global.teamIndex == 0) then
				player.force = game.forces["team1"];
				global.teamIndex = 1;
			else
				player.force = game.forces["team2"];
				global.teamIndex = 0;
			end
			player.print("joined team: " .. player.force.name);
		end
	end
);
script.on_event(
	defines.events.on_force_created,
	function(event)
		if(event.force.name == "enemy") then return end
		global.forces[event.force.name] = {};
		event.force.evolution_factor_by_pollution = 0;
		event.force.evolution_factor_by_time = 0;
		event.force.evolution_factor_by_killing_spawners  = 0;
        global.forces[event.force.name].buildBaseGroups = {};
        global.forces[event.force.name].evoThing = {};
        global.forces[event.force.name].evoPoints = 0;
        global.forces[event.force.name].evoCap = 0;
		table.insert(global.forces, event.force.name);
		if(event.force.name == "team2") then
			event.force.set_spawn_position(game.get_surface(1), global.spawnPos);
			game.get_surface(1).create_entity({
				name = "friendlyBiterSpawner",
				force = "team2",
				position = event.force.get_spawn_position(game.get_surface(1));
			});
		end
	end
);

script.on_event(
	{
		defines.events.on_built_entity,
		defines.events.on_robot_built_entity,
		defines.events.script_raised_built,
		defines.events.script_raised_revive
	}, 
	function(event)
		local ent = event.entity or event.created_entity;
		if(ent.name == "evoThing") then
			local force = ent.force;
			global.forces[force.name].evoThing[ent.unit_number] = ent;
		end
	end
)

script.on_event(
	{
		defines.events.on_entity_died,
		defines.events.on_player_mined_entity,
		defines.events.on_robot_mined_entity,
		defines.events.script_raised_destroy,
	}, 
	function(event)
		local ent = event.entity or event.created_entity;
		if(ent.name == "evoThing") then
			global.forces[ent.force.name].evoThing[ent.unit_number] = nil;
		end
	end
)

script.on_event(
	defines.events.on_player_selected_area, 
	function(event)
		if(event.item == "biterAttackSelectTool") then
			if(type(event.entities) == "table") then
				if(next(event.entities) == nil) then
					return;
				end
				global.forces[game.players[event.player_index].force.name].target = event.entities[1];
			end
		end
		if(event.item == "biterExpandSelectTool") then
			if(event.tiles ~= nil) then
				global.forces[game.players[event.player_index].force.name].target = event.tiles[1];
			end
		end

		if(event.item == "biterAttackTool") then
			if(global.forces[game.players[event.player_index].force.name].target == nil) then
				return;
			end
			if(event.entities == nil) then 
				return;
			end
			if(next(event.entities) == nil) then
				return;
			end
			local group = event.surface.create_unit_group{position = event.entities[1].position, force = "player"};
			for k,v in pairs(event.entities) do
				if(v.type == "unit") then
					group.add_member(v);
				end
			end
			group.set_command({
				type = defines.command.attack,
				target = global.forces[game.players[event.player_index].force.name].target,
				distraction = defines.distraction.none
			});
		end

		if(event.item == "biterExpandTool") then
			if(global.forces[game.players[event.player_index].force.name].target == nil) then
				return;
			end
			if(event.entities == nil) then 
				return;
			end
			if(next(event.entities) == nil) then
				return;
			end
			local group = event.surface.create_unit_group{position = event.entities[1].position, force = "player"};
			local v = event.entities[1];
			if(v.type == "unit") then
				group.add_member(v);
			end
			group.set_command({
				type = defines.command.go_to_location,
				destination = global.forces[game.players[event.player_index].force.name].target.position,
				distraction = defines.distraction.none
			});
			table.insert(global.forces[game.players[event.player_index].force.name].buildBaseGroups, group);
		end
	end
)
script.on_event(
	defines.events.on_tick,
	function()
		for force,_ in pairs(global.forces) do
			for k,v in pairs(global.forces[force].buildBaseGroups) do
				if(v.valid == false) then return end
				if(v.state == defines.group_state.finished) then
					local position = game.get_surface(1).find_non_colliding_position("biter-spawner", v.position, 5, 0.5);
					if(position ~= nil) then
						v.destroy();
						local spawn = nil;
						if(math.random(1,2) == 1) then
							spawn = "friendlyBiterSpawner";
						else
							spawn = "friendlySpitterSpawner";
						end
						game.get_surface(1).create_entity({
							name = spawn,
							force = "player",
							position = position
						});
						global.forces[force].buildBaseGroups[k] = nil;
					end
				end
			end
			local evoPoints = 0;
			for k,v in pairs(global.forces[force].evoThing) do
				local inventory = v.get_inventory(defines.inventory.furnace_result);
				if(inventory.is_empty() == false) then
					local count = inventory.get_item_count("processedGreenThing");
					evoPoints = evoPoints + count;
					inventory.clear();
				end
			end
			local evoFactor = global.forces[force].evoPoints + (evoPoints / 100);
			local factor = -math.pow(1.4,-evoFactor) + 1;
			if(factor <= global.forces[force].evoCap) then
				global.forces[force].evoPoints = evoFactor;
				if(evoFactor >= 14) then
					game.forces["player"].evolution_factor = 1;
				else
					game.forces["player"].evolution_factor = factor;
				end
			else
				game.forces["player"].evolution_factor = global.forces[force].evoCap;
			end
		end
	end
)
script.on_event(
	defines.events.on_research_finished,
	function(event)
		if(string.sub(event.research.name, 1, -3) == "evoultionCapUpgrade") then
			global.forces[event.research.force.name].evoCap = global.forces[event.research.force.name].evoCap + 0.1;
		end
	end
);